import {
  User, Learner, Educator, Category, Skill, EducatorSkill,
  Qualification, Portfolio, Verification, LearnerRequest,
  Match, Booking, Availability, Payment, Transaction, Review,
  Message, Notification, AdminAction
} from './types.js';

export const initialCategories: Category[] = [
  { id: 'cat-fashion', name: 'Fashion & Tailoring', slug: 'fashion-tailoring', description: 'Pattern drafting, garment cutting, sewing machine maintenance, African prints & bridal couture', icon_name: 'Scissors', sort_order: 1 },
  { id: 'cat-tech', name: 'Web Development & Programming', slug: 'web-programming', description: 'Frontend, backend, React, Node.js, Python, and practical software engineering', icon_name: 'Code', sort_order: 2 },
  { id: 'cat-repair', name: 'Phone Repair & Electronics', slug: 'phone-repair-electronics', description: 'Hardware diagnostics, screen replacement, micro-soldering, PCB troubleshooting', icon_name: 'Smartphone', sort_order: 3 },
  { id: 'cat-culinary', name: 'Cooking & Baking', slug: 'cooking-baking', description: 'Commercial pastry, artisan breads, cake decoration, culinary sanitation & catering', icon_name: 'Utensils', sort_order: 4 },
  { id: 'cat-electrical', name: 'Electrical & Solar', slug: 'electrical-solar', description: 'Domestic & industrial wiring, solar inverter setups, battery storage, safety compliance', icon_name: 'Zap', sort_order: 5 },
  { id: 'cat-welding', name: 'Welding & Metalwork', slug: 'welding-metalwork', description: 'MIG, TIG, stick welding, structural gates, metal fabrication, tool handling', icon_name: 'Hammer', sort_order: 6 },
  { id: 'cat-carpentry', name: 'Carpentry & Woodwork', slug: 'carpentry-woodwork', description: 'Custom furniture design, joinery, timber selection, finishing and restoration', icon_name: 'Wrench', sort_order: 7 },
  { id: 'cat-agriculture', name: 'Agriculture & Agribusiness', slug: 'agriculture-agribusiness', description: 'Commercial poultry, greenhouse horticulture, dairy farm management, drip irrigation', icon_name: 'Sprout', sort_order: 8 },
  { id: 'cat-photography', name: 'Photography & Video', slug: 'photography-video', description: 'Studio lighting, portraiture, Premiere Pro / DaVinci editing, commercial video', icon_name: 'Camera', sort_order: 9 },
  { id: 'cat-design', name: 'Graphic Design & UI/UX', slug: 'graphic-design-ui', description: 'Photoshop, Illustrator, branding, typography, Figma UI design & layout', icon_name: 'Palette', sort_order: 10 },
  { id: 'cat-business', name: 'Accounting & Business Skills', slug: 'accounting-business', description: 'QuickBooks, tax compliance with URA, bookkeeping, financial forecasting', icon_name: 'Briefcase', sort_order: 11 },
  { id: 'cat-marketing', name: 'Digital Marketing & Social Media', slug: 'digital-marketing', description: 'Performance marketing, Meta ads, SEO, TikTok & Reels content for SME growth', icon_name: 'TrendingUp', sort_order: 12 },
  { id: 'cat-beauty', name: 'Beauty & Hair Styling', slug: 'beauty-hair', description: 'Bridal makeup, skin prep, precision hair styling, manicures, salon hygiene', icon_name: 'Sparkles', sort_order: 13 },
  { id: 'cat-plumbing', name: 'Plumbing & Pipefitting', slug: 'plumbing', description: 'Domestic plumbing, PEX piping, drainage systems, water heater installations', icon_name: 'Droplets', sort_order: 14 },
  { id: 'cat-automotive', name: 'Automotive & Mechanics', slug: 'automotive', description: 'OBD diagnostics, engine overhaul, suspension, electrical troubleshooting', icon_name: 'Car', sort_order: 15 },
  { id: 'cat-communication', name: 'Communication & Career', slug: 'communication-career', description: 'Public speaking, interview prep, grant writing, corporate business English', icon_name: 'MessageSquare', sort_order: 16 },
  { id: 'cat-music', name: 'Music & Audio Production', slug: 'music-audio', description: 'Acoustic guitar, keyboard, vocal training, FL Studio / Logic beatmaking', icon_name: 'Music', sort_order: 17 },
  { id: 'cat-construction', name: 'Construction & Masonry', slug: 'construction-masonry', description: 'Bricklaying, tiling, concrete mixing, blueprint interpretation & site supervision', icon_name: 'Building2', sort_order: 18 },
  { id: 'cat-crafts', name: 'Crafts & Handmade Goods', slug: 'crafts', description: 'Beadwork, basket weaving, leather shoes & bags, pottery', icon_name: 'Feather', sort_order: 19 },
  { id: 'cat-ai', name: 'AI & Applied Technology', slug: 'ai-technology', description: 'Practical AI tools for business, workflow automation, prompt engineering', icon_name: 'Cpu', sort_order: 20 },
];

export const initialSkills: Skill[] = [
  { id: 'skill-tailoring-1', category_id: 'cat-fashion', name: 'Garment Pattern Drafting & Cutting', slug: 'pattern-drafting', description: 'Learn accurate manual pattern making for suits, dresses, and traditional attire.', level_options: ['beginner', 'intermediate', 'advanced'], typical_duration_hours: 20, popular: true },
  { id: 'skill-tailoring-2', category_id: 'cat-fashion', name: 'Industrial Sewing Machine Mastery', slug: 'industrial-sewing', description: 'Operating and maintaining heavy-duty straight-stitch and overlock industrial machines.', level_options: ['beginner', 'intermediate'], typical_duration_hours: 15, popular: true },
  { id: 'skill-web-1', category_id: 'cat-tech', name: 'Full-Stack Web Development (React & Node)', slug: 'fullstack-web-dev', description: 'Modern responsive web development with React, TypeScript, APIs and databases.', level_options: ['beginner', 'intermediate', 'advanced'], typical_duration_hours: 35, popular: true },
  { id: 'skill-web-2', category_id: 'cat-tech', name: 'Python for Beginners & Automation', slug: 'python-automation', description: 'Core Python fundamentals, scripting, data handling and daily task automation.', level_options: ['beginner', 'intermediate'], typical_duration_hours: 20, popular: false },
  { id: 'skill-phone-1', category_id: 'cat-repair', name: 'Smartphone Hardware Diagnostics & Repair', slug: 'smartphone-hardware-repair', description: 'Screen replacement, battery soldering, charging port repairs, and board schematics.', level_options: ['beginner', 'intermediate', 'advanced'], typical_duration_hours: 25, popular: true },
  { id: 'skill-phone-2', category_id: 'cat-repair', name: 'Micro-Soldering & Circuit Diagnostics', slug: 'microsoldering', description: 'SMD component soldering, heat gun calibration, microscope diagnostics.', level_options: ['intermediate', 'advanced'], typical_duration_hours: 20 },
  { id: 'skill-baking-1', category_id: 'cat-culinary', name: 'Commercial Pastry & Cake Decorating', slug: 'commercial-pastry-cake-decorating', description: 'Tiered wedding cakes, sharp fondant edges, Swiss meringue buttercream, and baking math.', level_options: ['beginner', 'intermediate', 'advanced'], typical_duration_hours: 18, popular: true },
  { id: 'skill-electrical-1', category_id: 'cat-electrical', name: 'Solar PV System Sizing & Installation', slug: 'solar-pv-installation', description: 'Load calculation, hybrid inverter setup, lithium battery bank wiring, safety earthing.', level_options: ['beginner', 'intermediate', 'advanced'], typical_duration_hours: 24, popular: true },
  { id: 'skill-electrical-2', category_id: 'cat-electrical', name: 'Domestic Single-Phase Electrical Wiring', slug: 'domestic-electrical-wiring', description: 'Conduit bending, consumer unit wiring, circuit breaker sizing to Ugandan ERA standards.', level_options: ['beginner', 'intermediate'], typical_duration_hours: 20 },
  { id: 'skill-welding-1', category_id: 'cat-welding', name: 'Electric Arc & MIG Welding', slug: 'arc-mig-welding', description: 'Joint prep, vertical & overhead welding beads, metal gate and grille fabrication.', level_options: ['beginner', 'intermediate', 'advanced'], typical_duration_hours: 25, popular: true },
  { id: 'skill-carpentry-1', category_id: 'cat-carpentry', name: 'Modern Cabinetry & Joinery', slug: 'cabinetry-joinery', description: 'Mortise & tenon joints, pocket screws, laminate finishing, kitchen carcass construction.', level_options: ['beginner', 'intermediate'], typical_duration_hours: 30, popular: true },
  { id: 'skill-agri-1', category_id: 'cat-agriculture', name: 'Commercial Broiler & Layer Poultry Farming', slug: 'poultry-farming-management', description: 'Brooding chamber setup, feed conversion ratios, vaccination schedules, bio-security.', level_options: ['beginner', 'intermediate'], typical_duration_hours: 16, popular: true },
  { id: 'skill-agri-2', category_id: 'cat-agriculture', name: 'Dairy Farming & Quality Milk Value Addition', slug: 'dairy-farming-value-addition', description: 'Pasture management, breed selection, silage production, hygienic milk handling.', level_options: ['beginner', 'intermediate'], typical_duration_hours: 20, popular: true },
  { id: 'skill-photo-1', category_id: 'cat-photography', name: 'Portrait & Studio Lighting Techniques', slug: 'studio-lighting-photography', description: 'Three-point lighting, speedlights, modifiers, manual camera exposure, model direction.', level_options: ['beginner', 'intermediate'], typical_duration_hours: 12, popular: true },
  { id: 'skill-photo-2', category_id: 'cat-photography', name: 'Video Editing in DaVinci Resolve & Premiere', slug: 'video-editing-color-grading', description: 'Rough cuts, timeline pacing, color grading, audio cleanup, social media exports.', level_options: ['beginner', 'intermediate'], typical_duration_hours: 18 },
  { id: 'skill-design-1', category_id: 'cat-design', name: 'Brand Identity & Vector Illustration (Illustrator)', slug: 'brand-identity-vector', description: 'Logo design, vector curves, typography rules, brand guideline document creation.', level_options: ['beginner', 'intermediate'], typical_duration_hours: 16, popular: true },
  { id: 'skill-biz-1', category_id: 'cat-business', name: 'SME Bookkeeping & QuickBooks Online', slug: 'sme-bookkeeping-quickbooks', description: 'Chart of accounts, invoicing, bank reconciliations, VAT / URA returns prep.', level_options: ['beginner', 'intermediate'], typical_duration_hours: 15, popular: true },
  { id: 'skill-beauty-1', category_id: 'cat-beauty', name: 'Professional Bridal & Glamour Makeup', slug: 'bridal-glamour-makeup', description: 'Skin prep for tropical climates, foundation matching, eye shadow blending, lash application.', level_options: ['beginner', 'intermediate'], typical_duration_hours: 15, popular: true }
];

export const initialUsers: User[] = [
  // Founder & Primary Admin
  {
    id: 'usr-admin-ashabahebwa',
    email: process.env.ADMIN_EMAIL || 'ashabahebwahassan665@gmail.com',
    password_hash: process.env.ADMIN_PASSWORD || 'admin123',
    role: 'admin',
    name: 'Ashabahebwa Hassan',
    phone: '+256 744 024 529',
    avatar_url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    created_at: '2026-01-01T08:00:00Z',
    updated_at: '2026-01-01T08:00:00Z'
  },
  // Real initial educators across Mbarara & Uganda
  {
    id: 'usr-edu-1',
    email: 'mukasa.tailor@iskilllink.ug',
    password_hash: 'edu123',
    role: 'educator',
    name: 'Joseph Mukasa',
    phone: '+256 774 521 300',
    avatar_url: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80',
    created_at: '2026-01-15T12:00:00Z',
    updated_at: '2026-01-15T12:00:00Z'
  },
  {
    id: 'usr-edu-2',
    email: 'kembabazi.tech@iskilllink.ug',
    password_hash: 'edu123',
    role: 'educator',
    name: 'Dr. Irene Kembabazi',
    phone: '+256 702 884 199',
    avatar_url: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=300&q=80',
    created_at: '2026-01-18T14:30:00Z',
    updated_at: '2026-01-18T14:30:00Z'
  },
  {
    id: 'usr-edu-3',
    email: 'emmanuel.kato@iskilllink.ug',
    password_hash: 'edu123',
    role: 'educator',
    name: 'Emmanuel Kato',
    phone: '+256 788 123 456',
    avatar_url: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=300&q=80',
    created_at: '2026-01-20T09:00:00Z',
    updated_at: '2026-01-20T09:00:00Z'
  },
  {
    id: 'usr-edu-4',
    email: 'grace.nalubega@iskilllink.ug',
    password_hash: 'edu123',
    role: 'educator',
    name: 'Grace Nalubega',
    phone: '+256 752 990 011',
    avatar_url: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=300&q=80',
    created_at: '2026-01-22T10:45:00Z',
    updated_at: '2026-01-22T10:45:00Z'
  },
  {
    id: 'usr-edu-5',
    email: 'david.ochen@iskilllink.ug',
    password_hash: 'edu123',
    role: 'educator',
    name: 'David Ochen',
    phone: '+256 779 341 556',
    avatar_url: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?auto=format&fit=crop&w=300&q=80',
    created_at: '2026-01-25T11:20:00Z',
    updated_at: '2026-01-25T11:20:00Z'
  },
  {
    id: 'usr-edu-6',
    email: 'tumusiime.dairy@iskilllink.ug',
    password_hash: 'edu123',
    role: 'educator',
    name: 'Justus Tumusiime',
    phone: '+256 772 884 319',
    avatar_url: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?auto=format&fit=crop&w=300&q=80',
    created_at: '2026-01-28T16:00:00Z',
    updated_at: '2026-01-28T16:00:00Z'
  },
  // Active Learner
  {
    id: 'usr-learner-1',
    email: 'sarah.namubiru@gmail.com',
    password_hash: 'learner123',
    role: 'learner',
    name: 'Sarah Namubiru',
    phone: '+256 701 455 890',
    avatar_url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
    created_at: '2026-02-01T10:00:00Z',
    updated_at: '2026-02-01T10:00:00Z'
  }
];

export const initialLearners: Learner[] = [
  {
    id: 'lrn-1',
    user_id: 'usr-learner-1',
    location: 'Mbarara & Kampala',
    bio: 'Passionate about bespoke African fashion design and launching a bespoke boutique brand in Uganda.',
    learning_interests: ['Garment Pattern Drafting', 'Industrial Sewing', 'Fashion Business'],
    preferred_format: 'in-person',
    created_at: '2026-02-01T10:00:00Z'
  }
];

export const initialEducators: Educator[] = [
  {
    id: 'edu-1',
    user_id: 'usr-edu-1',
    title: 'Master Tailor & Pattern Construction Instructor',
    bio: '12+ years of practical tailoring in Mbarara High Street and Kampala. Specializing in precision pattern drafting, menswear suits, African print garments, and industrial machine tuning. Trained over 80 independent apprentices.',
    educator_type: 'artisan',
    years_experience: 12,
    location: 'High Street, Mbarara City',
    service_area: 'Mbarara City, Kakoba, Kamukuzi, Greater Ankole & Kampala',
    teaching_formats: ['in-person', 'hybrid'],
    languages: ['English', 'Runyankole', 'Luganda'],
    equipment_provided: 'Equipped workshop with Juki industrial straight machines, 5-thread overlockers, cutting tables and drafting rulers.',
    hourly_rate_ugx: 35000,
    package_rate_ugx: 350000,
    status: 'active',
    verification_notes: 'Physical workshop inspected at Mbarara Commercial Complex. National ID verified. Practical seam test passed.',
    rating: 4.95,
    total_reviews: 24,
    total_students: 31,
    featured: true,
    created_at: '2026-01-15T12:00:00Z'
  },
  {
    id: 'edu-2',
    user_id: 'usr-edu-2',
    title: 'Senior Software Architect & Full-Stack Mentor',
    bio: '8+ years building enterprise systems across East Africa. Teaching modern TypeScript, React, Node.js, and API architecture with real production codebases instead of surface-level tutorials.',
    educator_type: 'professional',
    years_experience: 8,
    location: 'Mbarara University Tech Hub & Nakawa',
    service_area: 'Mbarara, Greater Kampala & Global Online',
    teaching_formats: ['online', 'hybrid', 'in-person'],
    languages: ['English', 'Runyankole'],
    equipment_provided: 'Live code review repository, staging cloud sandboxes, and recorded practical walkthroughs.',
    hourly_rate_ugx: 45000,
    package_rate_ugx: 480000,
    status: 'active',
    verification_notes: 'GitHub portfolio reviewed, degree in Computer Science verified.',
    rating: 4.98,
    total_reviews: 19,
    total_students: 26,
    featured: true,
    created_at: '2026-01-18T14:30:00Z'
  },
  {
    id: 'edu-3',
    user_id: 'usr-edu-3',
    title: 'Electronics Diagnostics & Micro-Soldering Specialist',
    bio: 'Practical bench trainer with 9 years restoring damaged motherboards, iPhone & Android IC chips, charging circuits, and display assemblies. Focused on troubleshooting methodology over guesswork.',
    educator_type: 'practitioner',
    years_experience: 9,
    location: 'Kakoba Road, Mbarara City',
    service_area: 'Mbarara City & Western Region',
    teaching_formats: ['in-person'],
    languages: ['Runyankole', 'English', 'Luganda'],
    equipment_provided: 'Stereo microscopes, hot air rework stations, multimeter diagnostic rigs, and sample test boards.',
    hourly_rate_ugx: 30000,
    package_rate_ugx: 320000,
    status: 'active',
    verification_notes: 'Workshop verified. 5 client references confirmed.',
    rating: 4.88,
    total_reviews: 15,
    total_students: 19,
    featured: true,
    created_at: '2026-01-20T09:00:00Z'
  },
  {
    id: 'edu-4',
    user_id: 'usr-edu-4',
    title: 'Commercial Pastry Chef & Confectionery Trainer',
    bio: 'Professional pastry chef trained in commercial baking, buttercream floral design, sharp fondant tiers, and micro-bakery unit economics. Hands-on kitchen sessions that build confidence.',
    educator_type: 'trainer',
    years_experience: 7,
    location: 'Booma & Kamukuzi, Mbarara',
    service_area: 'Mbarara City, Ruharo, Booma, Ntinda',
    teaching_formats: ['in-person', 'hybrid'],
    languages: ['English', 'Runyankole', 'Luganda'],
    equipment_provided: 'Commercial deck ovens, planetary mixers, turntable cake stands, precision temperature probes.',
    hourly_rate_ugx: 40000,
    package_rate_ugx: 380000,
    status: 'active',
    verification_notes: 'UNBS hygiene compliance certified. Kitchen studio verified.',
    rating: 4.92,
    total_reviews: 18,
    total_students: 23,
    featured: true,
    created_at: '2026-01-22T10:45:00Z'
  },
  {
    id: 'edu-5',
    user_id: 'usr-edu-5',
    title: 'ERA-Certified Electrician & Solar Systems Lead',
    bio: 'Licensed Wireman Class B with 11 years in solar microgrid sizing, backup inverter installations, and commercial distribution boards. Emphasizes safety protocols and Ugandan electrical codes.',
    educator_type: 'practitioner',
    years_experience: 11,
    location: 'Ruharo, Mbarara & Kampala',
    service_area: 'Mbarara, Greater Ankole, Kampala, Entebbe',
    teaching_formats: ['in-person', 'hybrid'],
    languages: ['English', 'Runyankole', 'Luganda', 'Swahili'],
    equipment_provided: 'Clamp meters, insulation resistance testers, crimping tools, solar test panels.',
    hourly_rate_ugx: 35000,
    package_rate_ugx: 360000,
    status: 'active',
    verification_notes: 'Electricity Regulatory Authority (ERA) permit verified. National ID validated.',
    rating: 4.90,
    total_reviews: 21,
    total_students: 27,
    featured: true,
    created_at: '2026-01-25T11:20:00Z'
  },
  {
    id: 'edu-6',
    user_id: 'usr-edu-6',
    title: 'Commercial Dairy Farm Management & Pasture Consultant',
    bio: '15 years managing intensive Friesian/Ankole cross dairy herds, silage processing, machine milking, and hygienic raw milk handling in Kiruhura and Mbarara.',
    educator_type: 'mentor',
    years_experience: 15,
    location: 'Biharwe / Mbarara District',
    service_area: 'Mbarara, Kiruhura, Isingiro, Bushenyi',
    teaching_formats: ['in-person'],
    languages: ['Runyankole', 'English'],
    equipment_provided: 'Working dairy farm facility with milking machines and feed preparation units.',
    hourly_rate_ugx: 45000,
    package_rate_ugx: 420000,
    status: 'active',
    verification_notes: 'Farm premises verified. Veterinary board affiliation validated.',
    rating: 4.96,
    total_reviews: 14,
    total_students: 18,
    featured: true,
    created_at: '2026-01-28T16:00:00Z'
  }
];

export const initialEducatorSkills: EducatorSkill[] = [
  { id: 'es-1', educator_id: 'edu-1', skill_id: 'skill-tailoring-1', skill_name: 'Garment Pattern Drafting & Cutting', category_id: 'cat-fashion', proficiency_level: 'advanced', hourly_rate_ugx: 35000, package_rate_ugx: 350000, description: 'Complete manual drafting from raw body measurements to precision master blocks.' },
  { id: 'es-2', educator_id: 'edu-1', skill_id: 'skill-tailoring-2', skill_name: 'Industrial Sewing Machine Mastery', category_id: 'cat-fashion', proficiency_level: 'advanced', hourly_rate_ugx: 30000, package_rate_ugx: 280000, description: 'Speed handling, stitch tension balance, and motor maintenance.' },
  { id: 'es-3', educator_id: 'edu-2', skill_id: 'skill-web-1', skill_name: 'Full-Stack Web Development (React & Node)', category_id: 'cat-tech', proficiency_level: 'advanced', hourly_rate_ugx: 45000, package_rate_ugx: 480000, description: 'Architecting scalable web applications, REST APIs, and state management.' },
  { id: 'es-4', educator_id: 'edu-2', skill_id: 'skill-web-2', skill_name: 'Python for Beginners & Automation', category_id: 'cat-tech', proficiency_level: 'intermediate', hourly_rate_ugx: 40000, package_rate_ugx: 380000, description: 'Clean Python scripting, web scraping, and database connectors.' },
  { id: 'es-5', educator_id: 'edu-3', skill_id: 'skill-phone-1', skill_name: 'Smartphone Hardware Diagnostics & Repair', category_id: 'cat-repair', proficiency_level: 'advanced', hourly_rate_ugx: 30000, package_rate_ugx: 320000, description: 'Diagnostic schematics, charging circuits, touch digitizers, power rail testing.' },
  { id: 'es-6', educator_id: 'edu-4', skill_id: 'skill-baking-1', skill_name: 'Commercial Pastry & Cake Decorating', category_id: 'cat-culinary', proficiency_level: 'advanced', hourly_rate_ugx: 40000, package_rate_ugx: 380000, description: 'Multi-tiered cakes, velvet crumb structure, fondant handling in tropical weather.' },
  { id: 'es-7', educator_id: 'edu-5', skill_id: 'skill-electrical-1', skill_name: 'Solar PV System Sizing & Installation', category_id: 'cat-electrical', proficiency_level: 'advanced', hourly_rate_ugx: 35000, package_rate_ugx: 360000, description: 'PV array sizing, MPPT charge controllers, lithium storage, surge protectors.' },
  { id: 'es-8', educator_id: 'edu-6', skill_id: 'skill-agri-2', skill_name: 'Dairy Farming & Quality Milk Value Addition', category_id: 'cat-agriculture', proficiency_level: 'advanced', hourly_rate_ugx: 45000, package_rate_ugx: 420000, description: 'Silage formulation, zero grazing shed design, mastitis prevention, milk testing.' }
];

export const initialQualifications: Qualification[] = [
  { id: 'q-1', educator_id: 'edu-1', title: 'Diploma in Garment & Fashion Design', institution: 'Directorate of Industrial Training (DIT) Uganda', year: 2014, verified: true },
  { id: 'q-2', educator_id: 'edu-2', title: 'BSc Computer Science & Software Engineering', institution: 'Makerere University / MUST', year: 2017, verified: true },
  { id: 'q-3', educator_id: 'edu-3', title: 'Advanced Electronics & Board Diagnostics Certificate', institution: 'Uganda Technical College', year: 2016, verified: true },
  { id: 'q-4', educator_id: 'edu-4', title: 'Certificate in Professional Pastry Arts', institution: 'Kampala Institute of Culinary Arts', year: 2018, verified: true },
  { id: 'q-5', educator_id: 'edu-5', title: 'Installation Permit Class B', institution: 'Electricity Regulatory Authority (ERA) Uganda', year: 2015, verified: true }
];

export const initialPortfolios: Portfolio[] = [
  { id: 'p-1', educator_id: 'edu-1', title: 'Bespoke 3-Piece Linen Groom Suit', description: 'Hand-tailored canvas interlining and custom lapel stitch finish in Mbarara.', image_url: 'https://images.unsplash.com/photo-1594938298603-c8148c4dae35?auto=format&fit=crop&w=600&q=80', tag: 'Garment Construction' },
  { id: 'p-2', educator_id: 'edu-2', title: 'Agri-Logistics Mobile Web Application', description: 'Real-time dairy collection tracking platform built with React and Node.js.', image_url: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&w=600&q=80', tag: 'Web Dev' },
  { id: 'p-3', educator_id: 'edu-3', title: 'Micro-soldered Logic Board Repair', description: 'Restored damaged charging circuit using 0.02mm jumper wire under microscope.', image_url: 'https://images.unsplash.com/photo-1588508065123-287b28e013da?auto=format&fit=crop&w=600&q=80', tag: 'Electronics' },
  { id: 'p-4', educator_id: 'edu-4', title: '4-Tier Hand-Painted Celebration Cake', description: 'Vanilla bean sponge with passion fruit curd and handmade sugar orchids.', image_url: 'https://images.unsplash.com/photo-1535141192574-5d4897c13136?auto=format&fit=crop&w=600&q=80', tag: 'Baking' },
  { id: 'p-5', educator_id: 'edu-5', title: '5kVA Hybrid Solar Installation (Mbarara Residence)', description: '4.8kWh Lithium storage with 8x 550W Canadian Solar panels.', image_url: 'https://images.unsplash.com/photo-1509391365360-2e959784a276?auto=format&fit=crop&w=600&q=80', tag: 'Solar PV' }
];

export const initialVerifications: Verification[] = [
  { id: 'v-1', educator_id: 'edu-1', national_id_number: 'CM840291038ABK', national_id_status: 'verified', background_check_status: 'verified', interview_status: 'completed', skill_assessment_status: 'verified', verified_by_admin_id: 'usr-admin-ashabahebwa', verified_at: '2026-01-16T10:00:00Z', notes: 'Master artisan with proven reputation in Mbarara High Street.' },
  { id: 'v-2', educator_id: 'edu-2', national_id_number: 'CF920194829KMN', national_id_status: 'verified', background_check_status: 'verified', interview_status: 'completed', skill_assessment_status: 'verified', verified_by_admin_id: 'usr-admin-ashabahebwa', verified_at: '2026-01-19T11:00:00Z', notes: 'Software engineering degrees validated directly.' },
  { id: 'v-3', educator_id: 'edu-3', national_id_number: 'CM890284918LOP', national_id_status: 'verified', background_check_status: 'verified', interview_status: 'completed', skill_assessment_status: 'verified', verified_by_admin_id: 'usr-admin-ashabahebwa', verified_at: '2026-01-21T15:30:00Z', notes: 'Shop visited in Kakoba; soldering equipment inspected.' },
  { id: 'v-4', educator_id: 'edu-4', national_id_number: 'CF940298192XYZ', national_id_status: 'verified', background_check_status: 'verified', interview_status: 'completed', skill_assessment_status: 'verified', verified_by_admin_id: 'usr-admin-ashabahebwa', verified_at: '2026-01-23T09:45:00Z', notes: 'Bakery kitchen hygiene and tool safety verified.' },
  { id: 'v-5', educator_id: 'edu-5', national_id_number: 'CM820938190QWE', national_id_status: 'verified', background_check_status: 'verified', interview_status: 'completed', skill_assessment_status: 'verified', verified_by_admin_id: 'usr-admin-ashabahebwa', verified_at: '2026-01-26T14:15:00Z', notes: 'ERA certification license verified.' }
];

export const initialLearnerRequests: LearnerRequest[] = [
  {
    id: 'req-1',
    learner_id: 'lrn-1',
    skill_id: 'skill-tailoring-1',
    skill_name: 'Garment Pattern Drafting & Cutting',
    skill_level: 'beginner',
    learning_goal: 'I want to master manual pattern drafting for female blazers and African print skirts so I can cut cleanly without fabric wastage.',
    format_preference: 'in-person',
    location: 'Mbarara City / Greater Ankole',
    preferred_schedule: 'Saturdays & Sundays, 10:00 AM - 1:00 PM',
    frequency: '2 sessions per week (4 weeks total)',
    budget_ugx: 280000,
    additional_notes: 'I have my own shears and tape measure; looking for workshop with industrial tables.',
    status: 'in_progress',
    contact_phone: '+256 701 455 890',
    learner_name: 'Sarah Namubiru',
    learner_email: 'sarah.namubiru@gmail.com',
    created_at: '2026-02-15T09:00:00Z'
  }
];

export const initialMatches: Match[] = [
  {
    id: 'match-1',
    request_id: 'req-1',
    educator_id: 'edu-1',
    match_score: 96,
    match_reasons: [
      'Exact skill match: Garment Pattern Drafting & Cutting',
      'Location compatibility: High Street, Mbarara City',
      'Format match: In-person hands-on workshop available',
      'Budget alignment: Educator hourly rate matches requested package budget'
    ],
    matched_by: 'system',
    status: 'accepted',
    created_at: '2026-02-15T09:05:00Z'
  }
];

export const initialBookings: Booking[] = [
  {
    id: 'bk-101',
    learner_id: 'lrn-1',
    educator_id: 'edu-1',
    request_id: 'req-1',
    skill_id: 'skill-tailoring-1',
    skill_name: 'Garment Pattern Drafting & Cutting (Module 1: Foundations)',
    format: 'in-person',
    location_or_link: 'Joseph Mukasa Workshop, Mbarara High Street Commercial Center',
    scheduled_date: '2026-02-28',
    start_time: '10:00',
    duration_hours: 3,
    total_amount_ugx: 105000,
    platform_fee_ugx: 10500,
    educator_payout_ugx: 94500,
    status: 'completed',
    notes: 'Covered bodice block measurements, dart manipulation, and collar patterns.',
    milestone_progress: 100,
    completed_at: '2026-02-28T13:15:00Z',
    created_at: '2026-02-18T10:00:00Z'
  }
];

export const initialPayments: Payment[] = [
  {
    id: 'pay-101',
    booking_id: 'bk-101',
    learner_id: 'lrn-1',
    educator_id: 'edu-1',
    amount_ugx: 105000,
    platform_fee_ugx: 10500,
    payout_amount_ugx: 94500,
    method: 'mtn_momo',
    payment_reference: 'MOMO-UG-2026-894102',
    status: 'completed',
    created_at: '2026-02-26T14:20:00Z',
    updated_at: '2026-02-28T13:30:00Z'
  }
];

export const initialTransactions: Transaction[] = [
  {
    id: 'tx-1',
    payment_id: 'pay-101',
    type: 'learner_charge',
    amount_ugx: 105000,
    description: 'Learner payment for Booking #BK-101 (MTN MoMo)',
    status: 'completed',
    created_at: '2026-02-26T14:20:00Z'
  },
  {
    id: 'tx-2',
    payment_id: 'pay-101',
    type: 'platform_commission',
    amount_ugx: 10500,
    description: '10% iSkillLink platform facilitation fee',
    status: 'completed',
    created_at: '2026-02-28T13:30:00Z'
  },
  {
    id: 'tx-3',
    payment_id: 'pay-101',
    type: 'educator_payout',
    amount_ugx: 94500,
    description: 'Educator session completion payout to Joseph Mukasa',
    status: 'completed',
    created_at: '2026-02-28T13:30:00Z'
  }
];

export const initialReviews: Review[] = [
  {
    id: 'rev-1',
    booking_id: 'bk-101',
    educator_id: 'edu-1',
    learner_id: 'lrn-1',
    learner_name: 'Sarah Namubiru',
    learner_avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
    rating: 5,
    skill_rating: 5,
    punctuality_rating: 5,
    communication_rating: 5,
    comment: 'Mzee Joseph is a master of his craft. He broke down the mathematics of pattern dart manipulation so clearly on brown paper. His workshop on High Street is well-organized with proper industrial cutting tables. Worth every shilling.',
    educator_reply: 'Thank you Sarah! You picked up the bodice fitting exceptionally fast. Looking forward to our next module.',
    is_verified: true,
    is_moderated: true,
    created_at: '2026-03-01T10:00:00Z'
  }
];

export const initialMessages: Message[] = [
  {
    id: 'msg-1',
    conversation_id: 'conv-sarah-joseph',
    sender_id: 'usr-learner-1',
    receiver_id: 'usr-edu-1',
    content: 'Hello Mr. Mukasa, I have booked our second module session. I will bring the 4-meter floral Kitenge we discussed!',
    is_read: true,
    created_at: '2026-03-01T09:00:00Z'
  },
  {
    id: 'msg-2',
    conversation_id: 'conv-sarah-joseph',
    sender_id: 'usr-edu-1',
    receiver_id: 'usr-learner-1',
    content: 'Good morning Sarah. Please bring your dressmaker carbon paper and tracing wheel so we can transfer dart lines onto the fabric cleanly.',
    is_read: true,
    created_at: '2026-03-01T09:20:00Z'
  }
];

export const initialNotifications: Notification[] = [
  {
    id: 'notif-1',
    user_id: 'usr-admin-ashabahebwa',
    type: 'system_alert',
    title: 'iSkillLink Operations Active',
    message: 'Welcome Ashabahebwa Hassan. Platform operations and verification queue initialized for Mbarara & Uganda.',
    link: '/admin-dashboard',
    is_read: false,
    created_at: '2026-03-01T08:00:00Z'
  }
];

export const initialAdminActions: AdminAction[] = [
  {
    id: 'act-1',
    admin_id: 'usr-admin-ashabahebwa',
    admin_name: 'Ashabahebwa Hassan',
    action_type: 'INITIALIZE_PLATFORM_OPERATIONS',
    target_entity: 'Platform',
    target_id: 'HQ-MBARARA',
    details: 'Founder Ashabahebwa Hassan initialized iSkillLink Uganda operations based in Mbarara City.',
    created_at: '2026-01-01T08:00:00Z'
  }
];
